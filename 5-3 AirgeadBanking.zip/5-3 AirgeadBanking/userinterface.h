#ifndef USERINTERFACE_H
#define USERINTERFACE_H

#include "Investment.h"

class UserInterface {
public:
    void getUserInput(double &initialInvestment, double &monthlyDeposit, double &annualInterest, int &years);
    void displayReport(Investment &investment);
};

#endif