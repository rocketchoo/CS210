#include "UserInterface.h"
#include <iostream>

void UserInterface::getUserInput(double &initialInvestment, double &monthlyDeposit, double &annualInterest, int &years) {
    std::cout << "Enter Initial Investment Amount: ";
    std::cin >> initialInvestment;
    std::cout << "Enter Monthly Deposit: ";
    std::cin >> monthlyDeposit;
    std::cout << "Enter Annual Interest: ";
    std::cin >> annualInterest;
    std::cout << "Enter Number of Years: ";
    std::cin >> years;
}

void UserInterface::displayReport(Investment &investment) {
    std::cout << "\nReport Without Monthly Deposits:\n";
    investment.calculateWithoutMonthlyDeposits();

    std::cout << "\nReport With Monthly Deposits:\n";
    investment.calculateWithMonthlyDeposits();
}
