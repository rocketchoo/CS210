// main.cpp
#include "UserInterface.h"
#include "Investment.h"

int main() {
    double initialInvestment, monthlyDeposit, annualInterest;
    int years;

    // Create UserInterface object to handle user input
    UserInterface ui;
    ui.getUserInput(initialInvestment, monthlyDeposit, annualInterest, years);

    // Create Investment object with user input values
    Investment investment(initialInvestment, monthlyDeposit, annualInterest, years);

    // Display the investment reports
    ui.displayReport(investment);

    return 0;
}