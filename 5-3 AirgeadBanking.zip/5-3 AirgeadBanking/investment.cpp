#include "Investment.h"
#include <iostream>
#include <iomanip>

Investment::Investment(double initInvest, double monthDep, double annInterest, int yrs)
    : initialInvestment(initInvest), monthlyDeposit(monthDep), annualInterest(annInterest), years(yrs) {}

void Investment::calculateWithoutMonthlyDeposits() {
    double balance = initialInvestment;
    double annualInterestRate = annualInterest / 100;

    std::cout << std::fixed << std::setprecision(2);
    std::cout << "Year\tYear End Balance\tYear End Earned Interest\n";
    std::cout << "---------------------------------------------------\n";

    for (int year = 1; year <= years; ++year) {
        double interestEarned = balance * annualInterestRate;
        balance += interestEarned;
        std::cout << year << "\t$" << balance << "\t\t$" << interestEarned << "\n";
    }
}

void Investment::calculateWithMonthlyDeposits() {
    double balance = initialInvestment;
    double monthlyInterestRate = annualInterest / 12 / 100;

    std::cout << std::fixed << std::setprecision(2);
    std::cout << "Year\tYear End Balance\tYear End Earned Interest\n";
    std::cout << "---------------------------------------------------\n";

    for (int year = 1; year <= years; ++year) {
        double interestEarned = 0.0;
        for (int month = 1; month <= 12; ++month) {
            double interest = balance * monthlyInterestRate;
            interestEarned += interest;
            balance += monthlyDeposit + interest;
        }
        std::cout << year << "\t$" << balance << "\t\t$" << interestEarned << "\n";
    }
}