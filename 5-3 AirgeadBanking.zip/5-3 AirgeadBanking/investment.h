#ifndef INVESTMENT_H
#define INVESTMENT_H

class Investment {
private:
    double initialInvestment;
    double monthlyDeposit;
    double annualInterest;
    int years;

public:
    Investment(double initInvest, double monthDep, double annInterest, int yrs);
    void calculateWithoutMonthlyDeposits();
    void calculateWithMonthlyDeposits();
};

#endif